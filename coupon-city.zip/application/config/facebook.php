<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}


$config['appId'] = '1413599752212245';
$config['secret'] = '8d024f2b7d57488541a56e1e279b5bea';
?>
